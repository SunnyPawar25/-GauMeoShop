import { Product } from '../types';

export const products: Product[] = [
  // Food - Cat
  {
    id: 1,
    name: 'Thức ăn mèo cao cấp - Cá hồi',
    category: 'food',
    petType: 'cat',
    price: 650000,
    image: 'https://images.unsplash.com/photo-1616668983570-a971956d8928?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBmb29kfGVufDF8fHx8MTc2NTY0MzIyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Thức ăn mèo làm từ cá hồi chất lượng cao, giàu axit béo omega-3',
    stock: 50
  },
  {
    id: 2,
    name: 'Thức ăn mèo hữu cơ - Gà',
    category: 'food',
    petType: 'cat',
    price: 720000,
    image: 'https://images.unsplash.com/photo-1616668983570-a971956d8928?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBmb29kfGVufDF8fHx8MTc2NTY0MzIyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Công thức gà hữu cơ với thành phần tự nhiên',
    stock: 45
  },
  
  // Food - Dog
  {
    id: 3,
    name: 'Thức ăn chó cao cấp - Thịt bò',
    category: 'food',
    petType: 'dog',
    price: 900000,
    image: 'https://images.unsplash.com/photo-1714068691210-073dc52c6c1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kfGVufDF8fHx8MTc2NTY0MzIyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Công thức thịt bò giàu dinh dưỡng cho chó trưởng thành',
    stock: 60
  },
  {
    id: 4,
    name: 'Thức ăn cho chó con - Gà và cơm',
    category: 'food',
    petType: 'dog',
    price: 820000,
    image: 'https://images.unsplash.com/photo-1714068691210-073dc52c6c1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kfGVufDF8fHx8MTc2NTY0MzIyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Công thức đặc biệt cho sự phát triển và tăng trưởng của chó con',
    stock: 40
  },

  // Drinks
  {
    id: 5,
    name: 'Máy uống nước tự động',
    category: 'drink',
    petType: 'both',
    price: 1150000,
    image: 'https://images.unsplash.com/photo-1598191645993-f54b53d32195?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBkcmlua2luZyUyMHdhdGVyfGVufDF8fHx8MTc2NTY0MzIyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Máy uống nước tự động có bộ lọc cho nước uống tươi',
    stock: 30
  },
  {
    id: 6,
    name: 'Sữa bổ sung dinh dưỡng',
    category: 'drink',
    petType: 'both',
    price: 475000,
    image: 'https://images.unsplash.com/photo-1598191645993-f54b53d32195?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBkcmlua2luZyUyMHdhdGVyfGVufDF8fHx8MTc2NTY0MzIyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Sữa bổ sung dinh dưỡng cho chó và mèo',
    stock: 55
  },

  // Medicines
  {
    id: 7,
    name: 'Thuốc phòng trị ve rận',
    category: 'medicine',
    petType: 'both',
    price: 1075000,
    image: 'https://images.unsplash.com/photo-1632236542159-809925d85fc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJ5JTIwbWVkaWNpbmV8ZW58MXx8fHwxNzY1NjQzMjI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Điều trị phòng chống ve rận hàng tháng',
    stock: 35
  },
  {
    id: 8,
    name: 'Thuốc bổ sung tiêu hóa',
    category: 'medicine',
    petType: 'both',
    price: 750000,
    image: 'https://images.unsplash.com/photo-1632236542159-809925d85fc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJ5JTIwbWVkaWNpbmV8ZW58MXx8fHwxNzY1NjQzMjI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Bổ sung men vi sinh cho sức khỏe tiêu hóa',
    stock: 48
  },
  {
    id: 9,
    name: 'Viên uống bổ khớp',
    category: 'medicine',
    petType: 'dog',
    price: 975000,
    image: 'https://images.unsplash.com/photo-1632236542159-809925d85fc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJ5JTIwbWVkaWNpbmV8ZW58MXx8fHwxNzY1NjQzMjI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Bổ sung glucosamine cho sức khỏe khớp ở chó',
    stock: 25
  },

  // Supplies
  {
    id: 10,
    name: 'Khay vệ sinh mèo cao cấp',
    category: 'supplies',
    petType: 'cat',
    price: 1250000,
    image: 'https://images.unsplash.com/photo-1520721973443-8f2bfd949b19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBzdXBwbGllc3xlbnwxfHx8fDE3NjU2NDMyMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Khay vệ sinh tự động làm sạch với kiểm soát mùi',
    stock: 20
  },
  {
    id: 11,
    name: 'Bộ xích và vòng cổ chó',
    category: 'supplies',
    petType: 'dog',
    price: 625000,
    image: 'https://images.unsplash.com/photo-1520721973443-8f2bfd949b19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBzdXBwbGllc3xlbnwxfHx8fDE3NjU2NDMyMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Dây xích nylon bền và vòng cổ có thể điều chỉnh',
    stock: 75
  },
  {
    id: 12,
    name: 'Bộ dụng cụ chải lông',
    category: 'supplies',
    petType: 'both',
    price: 1000000,
    image: 'https://images.unsplash.com/photo-1520721973443-8f2bfd949b19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBzdXBwbGllc3xlbnwxfHx8fDE3NjU2NDMyMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Bộ chải lông hoàn chỉnh với bàn chải, lược và kéo cắt móng',
    stock: 42
  },
  {
    id: 13,
    name: 'Giường thú cưng - Cỡ lớn',
    category: 'supplies',
    petType: 'both',
    price: 1650000,
    image: 'https://images.unsplash.com/photo-1520721973443-8f2bfd949b19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBzdXBwbGllc3xlbnwxfHx8fDE3NjU2NDMyMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Giường thú cưng mềm mại, có thể giặt với xốp cao cấp',
    stock: 28
  },

  // Toys
  {
    id: 14,
    name: 'Bộ đồ chơi tương tác cho mèo',
    category: 'toys',
    petType: 'cat',
    price: 500000,
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Bộ 5 đồ chơi tương tác giúp mèo vui chơi',
    stock: 90
  },
  {
    id: 15,
    name: 'Bộ đồ chơi gặm cho chó',
    category: 'toys',
    petType: 'dog',
    price: 625000,
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Đồ chơi cao su bền cho chó thích gặm',
    stock: 65
  },
  {
    id: 16,
    name: 'Cần câu lông vũ cho mèo',
    category: 'toys',
    petType: 'cat',
    price: 325000,
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Cần câu lông vũ tương tác cho mèo nghịch ngợm',
    stock: 88
  },
  {
    id: 17,
    name: 'Bộ bóng tennis',
    category: 'toys',
    petType: 'dog',
    price: 400000,
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Bộ 6 quả bóng tennis cho trò chơi ném và đuổi bắt',
    stock: 100
  },
  {
    id: 18,
    name: 'Đồ chơi xả thức ăn thông minh',
    category: 'toys',
    petType: 'both',
    price: 575000,
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Đồ chơi giải đố tương tác có chức năng xả thức ăn',
    stock: 52
  }
];