import { useState } from 'react';
import { User } from '../types';

interface LoginPageProps {
  onLogin: (user: User) => void;
  onNavigate: (page: string) => void;
}

// Mock users for demonstration
const mockUsers = [
  { id: 1, email: 'admin@gaumeoshop.com', password: 'admin123', name: 'Quản trị viên', role: 'admin' as const },
  { id: 2, email: 'user@example.com', password: 'user123', name: 'Nguyễn Văn A', role: 'user' as const }
];

export function LoginPage({ onLogin, onNavigate }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSignUp) {
      // Sign up logic
      if (!name || !email || !password) {
        setError('Vui lòng điền đầy đủ thông tin');
        return;
      }

      const newUser: User = {
        id: Date.now(),
        email,
        name,
        role: 'user'
      };

      onLogin(newUser);
    } else {
      // Login logic
      const user = mockUsers.find(u => u.email === email && u.password === password);

      if (user) {
        const { password: _, ...userWithoutPassword } = user;
        onLogin(userWithoutPassword);
      } else {
        setError('Email hoặc mật khẩu không chính xác');
      }
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-orange-50 to-pink-50 py-12 px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white text-3xl">🐾</span>
            </div>
            <h2 className="text-3xl text-gray-900 mb-2">
              {isSignUp ? 'Tạo tài khoản' : 'Chào mừng trở lại'}
            </h2>
            <p className="text-gray-600">
              {isSignUp ? 'Đăng ký để bắt đầu mua sắm' : 'Đăng nhập vào tài khoản GauMeoShop'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {isSignUp && (
              <div>
                <label className="block text-gray-700 mb-2">Họ và tên</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all"
                  placeholder="Nhập họ tên của bạn"
                />
              </div>
            )}

            <div>
              <label className="block text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all"
                placeholder="Nhập email của bạn"
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Mật khẩu</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all"
                placeholder="Nhập mật khẩu"
              />
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors"
            >
              {isSignUp ? 'Đăng ký' : 'Đăng nhập'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError('');
              }}
              className="text-orange-500 hover:text-orange-600 transition-colors"
            >
              {isSignUp ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký'}
            </button>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="text-sm text-gray-600 mb-2">Tài khoản Demo:</div>
            <div className="space-y-2 text-sm">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-gray-900">Quản trị: admin@gaumeoshop.com</div>
                <div className="text-gray-500">Mật khẩu: admin123</div>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-gray-900">Khách hàng: user@example.com</div>
                <div className="text-gray-500">Mật khẩu: user123</div>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={() => onNavigate('home')}
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              ← Về trang chủ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}