import { motion } from 'motion/react';

export function PartnerBrands() {
  const brands = [
    { name: 'Royal Canin', logo: '🐕' },
    { name: 'Pedigree', logo: '🦴' },
    { name: 'Whiskas', logo: '🐱' },
    { name: 'Me-O', logo: '😺' },
    { name: 'SmartHeart', logo: '❤️' },
    { name: 'Reflex', logo: '⭐' },
    { name: 'Cat\'s Eye', logo: '👁️' },
    { name: 'Minino', logo: '🐈' },
  ];

  return (
    <section className="bg-gradient-to-br from-orange-50 to-pink-50 py-12 sm:py-14 md:py-16">
      <div className="container mx-auto px-3 sm:px-4">
        <div className="text-center mb-8 sm:mb-10 md:mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-2 sm:mb-4">
              Đối tác thương hiệu
            </h2>
            <p className="text-sm sm:text-base text-gray-600">
              Chúng tôi hợp tác với các thương hiệu hàng đầu để mang đến sản phẩm chất lượng nhất
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4 md:gap-6">
          {brands.map((brand, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-5 md:p-6 shadow-md hover:shadow-xl transition-all cursor-pointer"
            >
              <div className="text-center">
                <div className="text-3xl sm:text-4xl mb-2 sm:mb-3">{brand.logo}</div>
                <div className="text-xs sm:text-sm text-gray-700">{brand.name}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}