import { ShoppingCart } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { formatVND } from "../utils/format";

const products = [
  {
    id: 1,
    name: "Thức ăn cho chó cao cấp",
    category: "Thức ăn & Dinh dưỡng",
    price: 3975000,
    rating: 4.8,
    image:
      "https://images.unsplash.com/photo-1598134493179-51332e56807f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBmb29kJTIwYm93bHxlbnwxfHx8fDE3NjU2MjIwODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    name: "Đồ chơi thông minh",
    category: "Đồ chơi & Giải trí",
    price: 750000,
    rating: 4.9,
    image:
      "https://images.unsplash.com/photo-1589924749359-9697080c3577?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzfGVufDF8fHx8MTc2NTYyMjA4NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    name: "Giường thú cưng êm ái",
    category: "Phụ kiện",
    price: 2250000,
    rating: 4.7,
    image:
      "https://images.unsplash.com/photo-1534361960057-19889db9621e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZ3xlbnwxfHx8fDE3NjU1ODk4NzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    name: "Bộ dụng cụ chải lông",
    category: "Sức khỏe & Chăm sóc",
    price: 875000,
    rating: 4.6,
    image:
      "https://images.unsplash.com/photo-1529778873920-4da4926a72c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXRlJTIwY2F0fGVufDF8fHx8MTc2NTYzMzkxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export function Products() {
  return (
    <section id="products" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-gray-900 mb-4">
            Sản phẩm thú cưng cao cấp
          </h2>
          <p className="text-xl text-gray-600">
            Sản phẩm chất lượng cho những người bạn bốn chân đáng yêu
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="relative">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-56 object-cover"
                />
                <span className="absolute top-3 left-3 bg-orange-500 text-white text-sm px-3 py-1 rounded-full">
                  ⭐ {product.rating}
                </span>
              </div>
              <div className="p-5">
                <p className="text-sm text-orange-500 mb-2">
                  {product.category}
                </p>
                <h3 className="text-xl text-gray-900 mb-3">
                  {product.name}
                </h3>
                <div className="flex items-center justify-between">
                  <span className="text-2xl text-gray-900">
                    {formatVND(product.price)}
                  </span>
                  <button className="bg-orange-500 text-white p-2 rounded-lg hover:bg-orange-600 transition-colors">
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600 transition-colors">
            Xem tất cả sản phẩm
          </button>
        </div>
      </div>
    </section>
  );
}
