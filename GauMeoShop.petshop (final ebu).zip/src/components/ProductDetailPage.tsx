import { useState } from 'react';
import { Star, ShoppingCart, Heart, Share2, Minus, Plus, Check, Truck, Shield, RotateCcw } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Product } from '../types';
import { products } from '../data/products';
import { formatVND } from '../utils/format';

interface ProductDetailPageProps {
  product: Product;
  onNavigate: (page: string) => void;
  addToCart: (product: Product, quantity: number) => void;
}

export function ProductDetailPage({ product, onNavigate, addToCart }: ProductDetailPageProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [addedToCart, setAddedToCart] = useState(false);

  // Mock images - in real app, product would have multiple images
  const images = [product.image, product.image, product.image, product.image];

  const relatedProducts = products
    .filter(p => p.id !== product.id && (p.category === product.category || p.petType === product.petType))
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const reviews = [
    { id: 1, name: 'Nguyễn Văn A', rating: 5, date: '01/12/2024', comment: 'Sản phẩm rất tốt, chó nhà tôi rất thích!' },
    { id: 2, name: 'Trần Thị B', rating: 4, date: '28/11/2024', comment: 'Chất lượng tốt, giao hàng nhanh' },
    { id: 3, name: 'Lê Văn C', rating: 5, date: '25/11/2024', comment: 'Giá cả hợp lý, sẽ mua lại' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-6 sm:py-8">
      <div className="container mx-auto px-3 sm:px-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs sm:text-sm mb-6 sm:mb-8 overflow-x-auto whitespace-nowrap">
          <button onClick={() => onNavigate('home')} className="text-gray-500 hover:text-orange-500">
            Trang chủ
          </button>
          <span className="text-gray-400">/</span>
          <button onClick={() => onNavigate('shop')} className="text-gray-500 hover:text-orange-500">
            Cửa hàng
          </button>
          <span className="text-gray-400">/</span>
          <span className="text-gray-900 truncate">{product.name}</span>
        </div>

        {/* Product Detail */}
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 mb-12 sm:mb-16">
          {/* Images */}
          <div>
            <div className="bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-lg mb-3 sm:mb-4">
              <ImageWithFallback
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-64 sm:h-80 md:h-96 lg:h-[500px] object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-2 sm:gap-3">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === idx ? 'border-orange-500' : 'border-gray-200'
                  }`}
                >
                  <ImageWithFallback
                    src={img}
                    alt={`${product.name} ${idx + 1}`}
                    className="w-full h-16 sm:h-20 md:h-24 object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-4 sm:p-6 md:p-8">
              <div className="flex items-center gap-2 mb-2 sm:mb-3">
                <span className="bg-orange-100 text-orange-600 px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm uppercase">
                  {product.category}
                </span>
                <span className="text-xl sm:text-2xl">
                  {product.petType === 'both' ? '🐱🐶' : product.petType === 'cat' ? '🐱' : '🐶'}
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-3 sm:mb-4">{product.name}</h1>

              {/* Rating */}
              <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <span className="text-sm sm:text-base text-gray-600">(45 đánh giá)</span>
              </div>

              <div className="text-2xl sm:text-3xl md:text-4xl text-orange-500 mb-4 sm:mb-6">{formatVND(product.price)}</div>

              <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">{product.description}</p>

              {/* Stock */}
              <div className="flex items-center gap-2 mb-4 sm:mb-6">
                {product.stock > 30 ? (
                  <>
                    <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm sm:text-base text-green-600">Còn hàng ({product.stock} sản phẩm)</span>
                  </>
                ) : product.stock > 0 ? (
                  <>
                    <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 bg-orange-500 rounded-full"></div>
                    <span className="text-sm sm:text-base text-orange-600">Sắp hết hàng ({product.stock} sản phẩm)</span>
                  </>
                ) : (
                  <>
                    <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 bg-red-500 rounded-full"></div>
                    <span className="text-sm sm:text-base text-red-600">Hết hàng</span>
                  </>
                )}
              </div>

              {/* Quantity Selector */}
              <div className="mb-4 sm:mb-6">
                <label className="block text-sm sm:text-base text-gray-700 mb-2 sm:mb-3">Số lượng:</label>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 md:gap-4">
                  <div className="flex items-center border-2 border-gray-300 rounded-lg">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="p-2 sm:p-3 hover:bg-gray-100 transition-colors"
                    >
                      <Minus className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <span className="px-4 sm:px-6 text-lg sm:text-xl">{quantity}</span>
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      className="p-2 sm:p-3 hover:bg-gray-100 transition-colors"
                      disabled={quantity >= product.stock}
                    >
                      <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>
                  <span className="text-sm sm:text-base text-gray-600">Tổng: {formatVND(product.price * quantity)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 sm:gap-3 mb-4 sm:mb-6">
                <button
                  onClick={handleAddToCart}
                  disabled={product.stock === 0}
                  className="flex-1 flex items-center justify-center gap-2 bg-orange-500 text-white py-3 sm:py-4 rounded-lg hover:bg-orange-600 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed text-sm sm:text-base"
                >
                  {addedToCart ? (
                    <>
                      <Check className="w-4 h-4 sm:w-5 sm:h-5" />
                      <span className="hidden sm:inline">Đã thêm vào giỏ!</span>
                      <span className="sm:hidden">Đã thêm!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5" />
                      <span className="hidden sm:inline">Thêm vào giỏ hàng</span>
                      <span className="sm:hidden">Thêm giỏ</span>
                    </>
                  )}
                </button>
                <button className="p-2.5 sm:p-3 md:p-4 border-2 border-gray-300 rounded-lg hover:border-orange-500 hover:text-orange-500 transition-colors flex-shrink-0">
                  <Heart className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                <button className="p-2.5 sm:p-3 md:p-4 border-2 border-gray-300 rounded-lg hover:border-orange-500 hover:text-orange-500 transition-colors flex-shrink-0">
                  <Share2 className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
              </div>

              {/* Features */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3 md:gap-4 pt-4 sm:pt-6 border-t border-gray-200">
                <div className="text-center">
                  <Truck className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-orange-500 mx-auto mb-1 sm:mb-2" />
                  <div className="text-xs sm:text-sm text-gray-600">Giao hàng miễn phí</div>
                </div>
                <div className="text-center">
                  <Shield className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-orange-500 mx-auto mb-1 sm:mb-2" />
                  <div className="text-xs sm:text-sm text-gray-600">Hàng chính hãng</div>
                </div>
                <div className="text-center">
                  <RotateCcw className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-orange-500 mx-auto mb-1 sm:mb-2" />
                  <div className="text-xs sm:text-sm text-gray-600">Đổi trả 7 ngày</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details & Reviews */}
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-4 sm:p-6 md:p-8 mb-12 sm:mb-16">
          <div className="flex gap-4 sm:gap-6 md:gap-8 border-b border-gray-200 mb-6 sm:mb-8 overflow-x-auto">
            <button className="pb-3 sm:pb-4 border-b-2 border-orange-500 text-orange-500 text-sm sm:text-base whitespace-nowrap">
              Chi tiết sản phẩm
            </button>
            <button className="pb-3 sm:pb-4 text-gray-600 hover:text-orange-500 transition-colors text-sm sm:text-base whitespace-nowrap">
              Đánh giá ({reviews.length})
            </button>
          </div>

          <div className="prose max-w-none">
            <h3 className="text-xl sm:text-2xl text-gray-900 mb-3 sm:mb-4">Mô tả chi tiết</h3>
            <p className="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">{product.description}</p>
            
            <h4 className="text-xl text-gray-900 mb-3">Thành phần:</h4>
            <ul className="text-gray-600 mb-4">
              <li>Protein chất lượng cao từ thịt tươi</li>
              <li>Vitamin và khoáng chất thiết yếu</li>
              <li>Không chất bảo quản, không màu tổng hợp</li>
              <li>Omega-3 và Omega-6 cho bộ lông bóng mượt</li>
            </ul>

            <h4 className="text-xl text-gray-900 mb-3">Hướng dẫn sử dụng:</h4>
            <p className="text-gray-600">
              Cho thú cưng ăn 2-3 lần mỗi ngày. Điều chỉnh lượng thức ăn phù hợp với cân nặng và mức độ hoạt động của thú cưng.
              Luôn đảm bảo có nước sạch.
            </p>
          </div>

          {/* Reviews */}
          <div className="mt-12 pt-8 border-t border-gray-200">
            <h3 className="text-2xl text-gray-900 mb-6">Đánh giá khách hàng</h3>
            <div className="space-y-6">
              {reviews.map(review => (
                <div key={review.id} className="border-b border-gray-200 pb-6 last:border-0">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="text-gray-900 mb-1">{review.name}</div>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= review.rating
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{review.date}</span>
                  </div>
                  <p className="text-gray-600">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-3xl text-gray-900 mb-8">Sản phẩm liên quan</h2>
            <div className="grid md:grid-cols-4 gap-6">
              {relatedProducts.map(relatedProduct => (
                <div
                  key={relatedProduct.id}
                  className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                  onClick={() => window.location.reload()}
                >
                  <ImageWithFallback
                    src={relatedProduct.image}
                    alt={relatedProduct.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <div className="text-sm text-orange-500 mb-2">{relatedProduct.category}</div>
                    <h3 className="text-lg text-gray-900 mb-2 line-clamp-2">{relatedProduct.name}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-xl text-gray-900">{formatVND(relatedProduct.price)}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          addToCart(relatedProduct);
                        }}
                        className="bg-orange-500 text-white p-2 rounded-lg hover:bg-orange-600 transition-colors"
                      >
                        <ShoppingCart className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}