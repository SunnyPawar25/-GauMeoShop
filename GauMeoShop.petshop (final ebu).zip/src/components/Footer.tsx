import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-white overflow-x-hidden">
      {/* Newsletter */}
      <div className="bg-gradient-to-r from-orange-500 to-pink-500 py-8 sm:py-10 md:py-12">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-xl sm:text-2xl md:text-3xl mb-2 sm:mb-3">Bản tin</h3>
            <p className="text-white/90 mb-4 sm:mb-6 text-sm sm:text-base">
              Đăng ký để nhận ưu đãi và tin tức
            </p>
            <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 max-w-xl mx-auto">
              <input
                type="email"
                placeholder="Nhập email của bạn"
                className="flex-1 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full text-gray-900 outline-none text-sm sm:text-base"
              />
              <button className="bg-white text-orange-500 px-6 sm:px-8 py-2.5 sm:py-3 rounded-full hover:bg-gray-100 transition-colors text-sm sm:text-base whitespace-nowrap">
                Đăng ký
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container mx-auto px-3 sm:px-4 py-10 sm:py-12 md:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-2 mb-4 sm:mb-6">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white text-xl sm:text-2xl">🐾</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xl sm:text-2xl truncate">GauMeoShop</span>
                <span className="text-xs text-gray-400 truncate">Chăm sóc thú cưng</span>
              </div>
            </div>
            <p className="text-gray-400 mb-4 sm:mb-6 text-sm sm:text-base">
              Đối tác tin cậy cho các sản phẩm chăm sóc thú cưng cao cấp. Chúng tôi cung cấp thức ăn, đồ chơi và phụ kiện chất lượng cho chó mèo yêu quý của bạn.
            </p>
            <div className="flex gap-2 sm:gap-3">
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors flex-shrink-0">
                <Facebook className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors flex-shrink-0">
                <Instagram className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors flex-shrink-0">
                <Twitter className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
              <a href="#" className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-orange-500 transition-colors flex-shrink-0">
                <Youtube className="w-4 h-4 sm:w-5 sm:h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg sm:text-xl mb-4 sm:mb-6">Liên kết nhanh</h3>
            <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base">
              <li>
                <button onClick={() => onNavigate('home')} className="text-gray-400 hover:text-orange-500 transition-colors">
                  Trang chủ
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('shop')} className="text-gray-400 hover:text-orange-500 transition-colors">
                  Cửa hàng
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="text-gray-400 hover:text-orange-500 transition-colors">
                  Giới thiệu
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('blog')} className="text-gray-400 hover:text-orange-500 transition-colors">
                  Blog
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="text-gray-400 hover:text-orange-500 transition-colors">
                  Liên hệ
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-lg sm:text-xl mb-4 sm:mb-6">Danh mục Cửa hàng</h3>
            <ul className="space-y-2 sm:space-y-3 text-sm sm:text-base">
              <li className="text-gray-400">🍖 Thức ăn</li>
              <li className="text-gray-400">💧 Đồ uống</li>
              <li className="text-gray-400">💊 Thuốc</li>
              <li className="text-gray-400">🛍️ Phụ kiện</li>
              <li className="text-gray-400">🎾 Đồ chơi</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg sm:text-xl mb-4 sm:mb-6">Thông tin liên hệ</h3>
            <ul className="space-y-3 sm:space-y-4 text-sm sm:text-base">
              <li className="flex items-start gap-2 sm:gap-3">
                <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500 flex-shrink-0 mt-1" />
                <span className="text-gray-400">
                  123 Ngõ 2, phường Trung Văn, quận Nam Từ Liêm, Hà Nội
                </span>
              </li>
              <li className="flex items-center gap-2 sm:gap-3">
                <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-400">0968305082 (8:00 AM - 9:00 PM)</span>
              </li>
              <li className="flex items-center gap-2 sm:gap-3">
                <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500 flex-shrink-0" />
                <span className="text-gray-400 break-all">contact@gaumeoshop.com</span>
              </li>
            </ul>
            
            <div className="mt-4 sm:mt-6">
              <h4 className="text-sm mb-2 sm:mb-3">Giờ làm việc</h4>
              <p className="text-gray-400 text-xs sm:text-sm">
                Thứ 2 - Thứ 7: 8:00 - 20:00<br/>
                Chủ nhật: 9:00 - 18:00
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4">
            <div className="text-gray-400 text-xs sm:text-sm text-center md:text-left">
              © 2024 GauMeoShop. Bản quyền thuộc về chúng tôi. Made with <Heart className="inline w-3 h-3 sm:w-4 sm:h-4 text-red-500 fill-red-500" /> for pets.
            </div>
            <div className="flex flex-wrap justify-center gap-3 sm:gap-4 md:gap-6 text-xs sm:text-sm">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors whitespace-nowrap">
                Chính sách bảo mật
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors whitespace-nowrap">
                Điều khoản dịch vụ
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors whitespace-nowrap">
                Chính sách đổi trả
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}