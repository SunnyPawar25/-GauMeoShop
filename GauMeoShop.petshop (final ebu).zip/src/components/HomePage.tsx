import { ArrowRight, Cat, Dog, ShoppingBag, Star, Truck, Shield, HeadphonesIcon } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Product } from '../types';
import { products } from '../data/products';
import { motion } from 'motion/react';
import { formatVND } from '../utils/format';
import { PartnerBrands } from './PartnerBrands';

interface HomePageProps {
  onNavigate: (page: string) => void;
  addToCart: (product: Product) => void;
  viewProduct: (product: Product) => void;
}

export function HomePage({ onNavigate, addToCart, viewProduct }: HomePageProps) {
  const featuredProducts = products.slice(0, 8);
  const categories = [
    { name: 'Thức ăn', icon: '🍖', category: 'food', color: 'from-orange-400 to-red-400' },
    { name: 'Đồ uống', icon: '💧', category: 'drink', color: 'from-blue-400 to-cyan-400' },
    { name: 'Thuốc men', icon: '💊', category: 'medicine', color: 'from-green-400 to-emerald-400' },
    { name: 'Đồ dùng', icon: '🛍️', category: 'supplies', color: 'from-purple-400 to-pink-400' },
    { name: 'Đồ chơi', icon: '🎾', category: 'toys', color: 'from-yellow-400 to-orange-400' }
  ];

  return (
    <div className="overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 overflow-hidden">
        <div className="container mx-auto px-3 sm:px-4 py-12 sm:py-16 md:py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-block bg-orange-100 text-orange-600 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full mb-4 sm:mb-6 text-sm sm:text-base">
                🐾 GauMeoShop
              </div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl text-gray-900 mb-4 sm:mb-6 leading-tight">
                GauMeoShop<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-pink-500">
                  Yêu thương trọn vẹn cho thú cưng
                </span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl text-gray-600 mb-6 sm:mb-8 leading-relaxed">
                Sản phẩm chất lượng cao cho chó và mèo của bạn
              </p>
              <div className="flex flex-wrap gap-3 sm:gap-4">
                <button
                  onClick={() => onNavigate('shop')}
                  className="flex items-center gap-2 bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:shadow-lg transition-all text-sm sm:text-base"
                >
                  <span>Mua sắm ngay</span>
                  <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
                <button
                  onClick={() => onNavigate('about')}
                  className="flex items-center gap-2 border-2 border-orange-500 text-orange-500 px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:bg-orange-50 transition-colors text-sm sm:text-base"
                >
                  <span>Về chúng tôi</span>
                </button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 sm:gap-6 mt-8 sm:mt-12">
                <div>
                  <div className="text-2xl sm:text-3xl text-orange-500 mb-1">15+</div>
                  <div className="text-xs sm:text-sm text-gray-600">Năm kinh nghiệm</div>
                </div>
                <div>
                  <div className="text-2xl sm:text-3xl text-pink-500 mb-1">50K+</div>
                  <div className="text-xs sm:text-sm text-gray-600">Khách hàng</div>
                </div>
                <div>
                  <div className="text-2xl sm:text-3xl text-purple-500 mb-1">1000+</div>
                  <div className="text-xs sm:text-sm text-gray-600">Sản phẩm</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-3 sm:space-y-4">
                  <div className="rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1592194996308-7b43878e84a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBwbGF5aW5nfGVufDF8fHx8MTc2NTUyMzcxNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="Cat"
                      className="w-full h-48 sm:h-56 md:h-64 object-cover"
                    />
                  </div>
                  <div className="bg-white p-4 sm:p-6 rounded-xl sm:rounded-2xl shadow-lg">
                    <Cat className="w-6 h-6 sm:w-8 sm:h-8 text-orange-500 mb-1 sm:mb-2" />
                    <h3 className="text-base sm:text-xl text-gray-900 mb-0.5 sm:mb-1">Sản phẩm cho mèo</h3>
                    <p className="text-gray-600 text-xs sm:text-sm">Chăm sóc tốt nhất</p>
                  </div>
                </div>
                <div className="space-y-3 sm:space-y-4 pt-8 sm:pt-12">
                  <div className="bg-white p-4 sm:p-6 rounded-xl sm:rounded-2xl shadow-lg">
                    <Dog className="w-6 h-6 sm:w-8 sm:h-8 text-pink-500 mb-1 sm:mb-2" />
                    <h3 className="text-base sm:text-xl text-gray-900 mb-0.5 sm:mb-1">Sản phẩm cho chó</h3>
                    <p className="text-gray-600 text-xs sm:text-sm">Chăm sóc tốt nhất</p>
                  </div>
                  <div className="rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1609348490161-a879e4327ae9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZyUyMHBvcnRyYWl0fGVufDF8fHx8MTc2NTYwMTAzM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="Dog"
                      className="w-full h-48 sm:h-56 md:h-64 object-cover"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 right-10 w-20 h-20 bg-orange-200 rounded-full blur-3xl opacity-50"></div>
        <div className="absolute bottom-20 left-10 w-32 h-32 bg-pink-200 rounded-full blur-3xl opacity-50"></div>
      </section>

      {/* Categories */}
      <section className="py-12 sm:py-16 md:py-20 bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-2 sm:mb-4">Danh mục sản phẩm</h2>
            <p className="text-base sm:text-lg md:text-xl text-gray-600">Khám phá các sản phẩm chất lượng cao</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4 md:gap-6">
            {categories.map((cat, idx) => (
              <button
                key={idx}
                onClick={() => onNavigate('shop')}
                className="group bg-white p-4 sm:p-6 md:p-8 rounded-2xl sm:rounded-3xl shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2"
              >
                <div className={`w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 bg-gradient-to-br ${cat.color} rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-2 sm:mb-3 md:mb-4 group-hover:scale-110 transition-transform`}>
                  <span className="text-2xl sm:text-3xl md:text-4xl">{cat.icon}</span>
                </div>
                <h3 className="text-sm sm:text-base md:text-lg text-gray-900">{cat.name}</h3>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 sm:py-16 md:py-20 bg-gradient-to-b from-pink-50 to-purple-50">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="flex items-center justify-between mb-8 sm:mb-12">
            <div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-1 sm:mb-2">Sản phẩm nổi bật</h2>
              <p className="text-sm sm:text-base md:text-xl text-gray-600">Được khách hàng yêu thích nhất</p>
            </div>
            <button
              onClick={() => onNavigate('shop')}
              className="hidden md:flex items-center gap-2 text-orange-500 hover:text-orange-600 transition-colors"
            >
              <span>Xem tất cả</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
            {featuredProducts.map(product => (
              <div
                key={product.id}
                onClick={() => viewProduct(product)}
                className="group bg-white rounded-2xl md:rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition-all cursor-pointer"
              >
                <div className="relative overflow-hidden">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-40 md:h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-2 md:top-4 right-2 md:right-4 bg-white px-2 md:px-3 py-1 rounded-full shadow-lg">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 md:w-4 md:h-4 text-yellow-400 fill-yellow-400" />
                      <span className="text-xs md:text-sm">4.8</span>
                    </div>
                  </div>
                  <span className="absolute top-2 md:top-4 left-2 md:left-4 bg-orange-500 text-white px-2 md:px-3 py-1 rounded-full text-xs md:text-sm">
                    {product.petType === 'both' ? '🐱🐶' : product.petType === 'cat' ? '🐱' : '🐶'}
                  </span>
                </div>
                <div className="p-3 md:p-6">
                  <div className="text-xs md:text-sm text-orange-500 mb-1 md:mb-2 uppercase">{product.category}</div>
                  <h3 className="text-sm md:text-lg text-gray-900 mb-1 md:mb-2 line-clamp-2 group-hover:text-orange-500 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-gray-600 text-xs md:text-sm mb-2 md:mb-4 line-clamp-2 hidden md:block">{product.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-base md:text-2xl text-gray-900">{formatVND(product.price)}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart(product);
                      }}
                      className="bg-orange-500 text-white p-2 md:p-3 rounded-lg md:rounded-xl hover:bg-orange-600 transition-colors"
                    >
                      <ShoppingBag className="w-4 h-4 md:w-5 md:h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8 sm:mt-12 md:hidden">
            <button
              onClick={() => onNavigate('shop')}
              className="bg-orange-500 text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-full hover:bg-orange-600 transition-colors text-sm sm:text-base"
            >
              Xem tất cả
            </button>
          </div>
        </div>
      </section>

      {/* Partner Brands */}
      <PartnerBrands />

      {/* Why Choose Us */}
      <section className="py-12 sm:py-16 md:py-20 bg-white">
        <div className="container mx-auto px-3 sm:px-4">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-2 sm:mb-4">Tại sao chọn chúng tôi</h2>
            <p className="text-base sm:text-lg md:text-xl text-gray-600">Cam kết chất lượng và dịch vụ tốt nhất</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <Truck className="w-8 h-8 sm:w-10 sm:h-10 text-orange-500" />
              </div>
              <h3 className="text-base sm:text-lg md:text-xl text-gray-900 mb-1 sm:mb-2 md:mb-3">Giao hàng miễn phí</h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-600">Miễn phí vận chuyển đơn từ 500.000đ</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-pink-100 to-pink-200 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <Shield className="w-8 h-8 sm:w-10 sm:h-10 text-pink-500" />
              </div>
              <h3 className="text-base sm:text-lg md:text-xl text-gray-900 mb-1 sm:mb-2 md:mb-3">Sản phẩm chính hãng</h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-600">100% hàng chính hãng, chất lượng đảm bảo</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <HeadphonesIcon className="w-8 h-8 sm:w-10 sm:h-10 text-blue-500" />
              </div>
              <h3 className="text-base sm:text-lg md:text-xl text-gray-900 mb-1 sm:mb-2 md:mb-3">Hỗ trợ 24/7</h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-600">Tư vấn chăm sóc thú cưng mọi lúc</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-green-100 to-green-200 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                <Star className="w-8 h-8 sm:w-10 sm:h-10 text-green-500" />
              </div>
              <h3 className="text-base sm:text-lg md:text-xl text-gray-900 mb-1 sm:mb-2 md:mb-3">Chất lượng cao</h3>
              <p className="text-xs sm:text-sm md:text-base text-gray-600">Sản phẩm được tuyển chọn kỹ lưỡng</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-12 sm:py-16 md:py-20 bg-gradient-to-br from-orange-500 via-pink-500 to-purple-500">
        <div className="container mx-auto px-3 sm:px-4 text-center text-white">
          <h2 className="text-3xl sm:text-4xl md:text-5xl mb-4 sm:mb-6">Mua sắm ngay hôm nay</h2>
          <p className="text-base sm:text-lg md:text-xl mb-6 sm:mb-8 opacity-90 max-w-2xl mx-auto">
            Khám phá hàng ngàn sản phẩm chất lượng cao cho thú cưng của bạn
          </p>
          <div className="flex gap-3 sm:gap-4 justify-center flex-wrap">
            <button
              onClick={() => onNavigate('shop')}
              className="bg-white text-orange-500 px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:bg-gray-100 transition-colors text-sm sm:text-base"
            >
              Mua sắm ngay
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="border-2 border-white text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:bg-white/10 transition-colors text-sm sm:text-base"
            >
              Liên hệ
            </button>
  
          </div>
        </div>
      </section>
    </div>
  );
}