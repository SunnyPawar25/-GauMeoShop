import { Heart, Award, Users, TrendingUp } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface AboutPageProps {
  onNavigate: (page: string) => void;
}

export function AboutPage({ onNavigate }: AboutPageProps) {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-gradient-to-br from-orange-50 to-pink-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl text-gray-900 mb-6">
            Về GauMeoShop
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Chúng tôi cam kết mang đến những sản phẩm và dịch vụ
            chất lượng nhất cho thú cưng của bạn
          </p>
        </div>
      </div>

      {/* Our Story */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl text-gray-900 mb-6">
                Câu chuyện của chúng tôi
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                GauMeoShop được thành lập vào năm 2010 với mục
                tiêu cung cấp những sản phẩm chăm sóc thú cưng
                chất lượng cao nhất tại Việt Nam. Khởi đầu từ
                một cửa hàng nhỏ, chúng tôi đã phát triển thành
                một trong những địa chỉ tin cậy nhất cho người
                yêu thú cưng.
              </p>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Với đội ngũ nhân viên giàu kinh nghiệm và đam mê
                thú cưng, chúng tôi luôn sẵn sàng tư vấn và hỗ
                trợ khách hàng chọn lựa sản phẩm phù hợp nhất
                cho bạn đồng hành bốn chân của mình.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Chúng tôi tin rằng mỗi thú cưng đều xứng đáng
                được yêu thương và chăm sóc tốt nhất. Đó là lý
                do chúng tôi chỉ cung cấp những sản phẩm đạt
                tiêu chuẩn chất lượng cao nhất.
              </p>
              <button
                onClick={() => onNavigate("shop")}
                className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600 transition-colors"
              >
                Khám phá sản phẩm
              </button>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1674678312970-ae74b1db3024?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBldHMlMjBmYW1pbHl8ZW58MXx8fHwxNzY1NTQ1ODA3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Happy pets family"
                className="w-full h-[500px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-20 bg-gradient-to-br from-orange-500 to-pink-500 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl mb-3">15+</div>
              <div className="text-xl">Năm kinh nghiệm</div>
            </div>
            <div>
              <div className="text-5xl mb-3">50K+</div>
              <div className="text-xl">Khách hàng hài lòng</div>
            </div>
            <div>
              <div className="text-5xl mb-3">1000+</div>
              <div className="text-xl">Sản phẩm đa dạng</div>
            </div>
            <div>
              <div className="text-5xl mb-3">20+</div>
              <div className="text-xl">Nhân viên tận tâm</div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-gray-900 mb-4">
              Giá trị cốt lõi
            </h2>
            <p className="text-xl text-gray-600">
              Những giá trị chúng tôi luôn hướng tới
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-xl text-gray-900 mb-3">
                Yêu thương
              </h3>
              <p className="text-gray-600">
                Chúng tôi yêu thương động vật và cam kết mang
                đến điều tốt nhất cho chúng
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Award className="w-8 h-8 text-pink-500" />
              </div>
              <h3 className="text-xl text-gray-900 mb-3">
                Chất lượng
              </h3>
              <p className="text-gray-600">
                Chỉ cung cấp sản phẩm chính hãng, đạt tiêu chuẩn
                chất lượng quốc tế
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-blue-500" />
              </div>
              <h3 className="text-xl text-gray-900 mb-3">
                Tận tâm
              </h3>
              <p className="text-gray-600">
                Đội ngũ nhân viên luôn sẵn sàng tư vấn và hỗ trợ
                khách hàng nhiệt tình
              </p>
            </div>

            <div className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl text-gray-900 mb-3">
                Phát triển
              </h3>
              <p className="text-gray-600">
                Không ngừng cải thiện và phát triển để phục vụ
                khách hàng tốt hơn
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl text-gray-900 mb-4">
              Đội ngũ của chúng tôi
            </h2>
            <p className="text-xl text-gray-600">
              Những người đam mê thú cưng
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                name: "Thái Ngọc Anh",
                role: "Giám đốc điều hành",
                image:
                  "https://693e9b799de40f1c26a16430.imgix.net/veterinarian_3621421.png",
              },
              {
                name: "Trần Thị Giang",
                role: "Chuyên gia dinh dưỡng",
                image:
                  "https://693e9b799de40f1c26a16430.imgix.net/veterinarian_3621358.png",
              },
              {
                name: "Nguyễn Huyền My",
                role: "Bác sĩ thú y",
                image:
                  "https://693e9b799de40f1c26a16430.imgix.net/veterinarian_3621358.png",
              },
              {
                name: "Nguyễn Văn Đạt",
                role: "Chuyên viên chăm sóc",
                image:
                  "https://693e9b799de40f1c26a16430.imgix.net/veterinarian_3621421.png",
              },
            ].map((member, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <ImageWithFallback
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6 text-center">
                  <h3 className="text-xl text-gray-900 mb-2">
                    {member.name}
                  </h3>
                  <p className="text-gray-600">{member.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-br from-orange-500 to-pink-500 rounded-3xl p-12 text-center text-white">
            <h2 className="text-4xl mb-6">
              Sẵn sàng mua sắm cho thú cưng của bạn?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Khám phá hàng ngàn sản phẩm chất lượng cao dành
              cho chó mèo
            </p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => onNavigate("shop")}
                className="bg-white text-orange-500 px-8 py-3 rounded-full hover:bg-gray-100 transition-colors"
              >
                Mua sắm ngay
              </button>
              <button
                onClick={() => onNavigate("contact")}
                className="border-2 border-white text-white px-8 py-3 rounded-full hover:bg-white/10 transition-colors"
              >
                Liên hệ chúng tôi
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}