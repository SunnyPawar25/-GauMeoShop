import { ShoppingBag, Heart, Phone } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <div className="relative bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Navigation */}
      <nav className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-8 h-8 text-purple-600 fill-purple-600" />
            <span className="text-2xl text-gray-900">PawPerfect</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#pets" className="text-gray-700 hover:text-purple-600 transition-colors">Pets</a>
            <a href="#products" className="text-gray-700 hover:text-purple-600 transition-colors">Products</a>
            <a href="#services" className="text-gray-700 hover:text-purple-600 transition-colors">Services</a>
            <a href="#contact" className="text-gray-700 hover:text-purple-600 transition-colors">Contact</a>
          </div>
          <button className="flex items-center gap-2 bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition-colors">
            <ShoppingBag className="w-5 h-5" />
            <span>Cart (0)</span>
          </button>
        </div>
      </nav>

      {/* Hero Content */}
      <div className="container mx-auto px-4 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-6xl text-gray-900 mb-6">
              Everything Your Pet Needs
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              From adorable companions to premium supplies, we're your one-stop shop for all things pet care.
            </p>
            <div className="flex gap-4">
              <button className="bg-purple-600 text-white px-8 py-3 rounded-full hover:bg-purple-700 transition-colors">
                Browse Pets
              </button>
              <button className="border-2 border-purple-600 text-purple-600 px-8 py-3 rounded-full hover:bg-purple-50 transition-colors">
                Shop Supplies
              </button>
            </div>
            <div className="mt-12 flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-purple-600" />
                <span className="text-gray-700">(555) 123-4567</span>
              </div>
              <span className="text-gray-400">|</span>
              <span className="text-gray-600">Open Mon-Sat 9AM-7PM</span>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1516453734593-8d198ae84bcf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBzdG9yZXxlbnwxfHx8fDE3NjU1NTkzMzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Pet store interior"
                className="w-full h-[500px] object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
