import { Calendar, User, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface BlogPageProps {
  onNavigate: (page: string) => void;
  viewBlog: (blogId: number) => void;
}

export const blogPosts = [
  {
    id: 1,
    title: '10 Loại thức ăn tốt nhất cho chó con',
    excerpt: 'Khám phá những loại thức ăn giàu dinh dưỡng giúp chó con phát triển khỏe mạnh...',
    image: 'https://images.unsplash.com/photo-1714068691210-073dc52c6c1d',
    author: 'Nguyễn Văn A',
    date: '2024-12-10',
    category: 'Dinh dưỡng',
    readTime: '5 phút đọc'
  },
  {
    id: 2,
    title: 'Cách chăm sóc mèo trong mùa đông',
    excerpt: 'Những lưu ý quan trọng khi chăm sóc mèo trong thời tiết lạnh...',
    image: 'https://images.unsplash.com/photo-1529778873920-4da4926a72c2',
    author: 'Trần Thị B',
    date: '2024-12-08',
    category: 'Chăm sóc',
    readTime: '7 phút đọc'
  },
  {
    id: 4,
    title: 'Bệnh thường gặp ở mèo và cách phòng tránh',
    excerpt: 'Tìm hiểu về các bệnh phổ biến ở mèo và biện pháp phòng ngừa hiệu quả...',
    image: 'https://images.unsplash.com/photo-1632236542159-809925d85fc0',
    author: 'Phạm Thị D',
    date: '2024-12-03',
    category: 'Sức khỏe',
    readTime: '8 phút đọc'
  },
  {
    id: 5,
    title: 'Đồ chơi giúp thú cưng phát triển trí thông minh',
    excerpt: 'Những loại đồ chơi giúp kích thích trí tuệ và giảm stress cho chó mèo...',
    image: 'https://images.unsplash.com/photo-1589924749359-9697080c3577',
    author: 'Hoàng Văn E',
    date: '2024-12-01',
    category: 'Giải trí',
    readTime: '6 phút đọc'
  },
  {
    id: 6,
    title: 'Cách chọn thức ăn phù hợp cho thú cưng già',
    excerpt: 'Hướng dẫn lựa chọn thực phẩm dinh dưỡng cho chó mèo lớn tuổi...',
    image: 'https://images.unsplash.com/photo-1616668983570-a971956d8928',
    author: 'Vũ Thị F',
    date: '2024-11-28',
    category: 'Dinh dưỡng',
    readTime: '9 phút đọc'
  }
];

export function BlogPage({ onNavigate, viewBlog }: BlogPageProps) {
  const featuredPost = blogPosts[0];
  const otherPosts = blogPosts.slice(1);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <div className="bg-gradient-to-br from-orange-50 to-pink-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl text-gray-900 mb-6">Blog & Tin tức</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Kiến thức hữu ích về chăm sóc và nuôi dưỡng thú cưng
          </p>
        </div>
      </div>

      {/* Featured Post */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div
            onClick={() => viewBlog(featuredPost.id)}
            className="bg-white rounded-3xl shadow-2xl overflow-hidden cursor-pointer hover:shadow-3xl transition-shadow grid md:grid-cols-2"
          >
            <div className="relative h-[400px]">
              <ImageWithFallback
                src={featuredPost.image}
                alt={featuredPost.title}
                className="w-full h-full object-cover"
              />
              <span className="absolute top-6 left-6 bg-orange-500 text-white px-4 py-2 rounded-full">
                Nổi bật
              </span>
            </div>
            <div className="p-12 flex flex-col justify-center">
              <div className="flex items-center gap-4 mb-4">
                <span className="bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-sm">
                  {featuredPost.category}
                </span>
                <span className="text-gray-500 text-sm">{featuredPost.readTime}</span>
              </div>
              <h2 className="text-4xl text-gray-900 mb-4">{featuredPost.title}</h2>
              <p className="text-gray-600 mb-6 text-lg">{featuredPost.excerpt}</p>
              <div className="flex items-center gap-4 mb-6">
                <User className="w-5 h-5 text-gray-400" />
                <span className="text-gray-600">{featuredPost.author}</span>
                <span className="text-gray-400">•</span>
                <Calendar className="w-5 h-5 text-gray-400" />
                <span className="text-gray-600">{featuredPost.date}</span>
              </div>
              <button className="flex items-center gap-2 text-orange-500 hover:text-orange-600 transition-colors">
                <span>Đọc thêm</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl text-gray-900 mb-8">Bài viết mới nhất</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {otherPosts.map(post => (
              <div
                key={post.id}
                onClick={() => viewBlog(post.id)}
                className="bg-white rounded-2xl shadow-lg overflow-hidden cursor-pointer hover:shadow-xl transition-shadow group"
              >
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <span className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm">
                    {post.category}
                  </span>
                </div>
                <div className="p-6">
                  <h3 className="text-xl text-gray-900 mb-3 line-clamp-2 group-hover:text-orange-500 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-br from-orange-500 to-pink-500 rounded-3xl p-12 text-center text-white">
            <h2 className="text-4xl mb-6">Đăng ký nhận bài viết mới</h2>
            <p className="text-xl mb-8 opacity-90">
              Nhận những bài viết hữu ích về chăm sóc thú cưng qua email
            </p>
            <div className="flex gap-3 max-w-xl mx-auto">
              <input
                type="email"
                placeholder="Nhập email của bạn..."
                className="flex-1 px-6 py-3 rounded-full text-gray-900 outline-none"
              />
              <button className="bg-white text-orange-500 px-8 py-3 rounded-full hover:bg-gray-100 transition-colors whitespace-nowrap">
                Đăng ký
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}