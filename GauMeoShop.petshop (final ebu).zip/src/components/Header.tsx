import { ShoppingCart, User as UserIcon, LogOut, Menu, X, Shield } from 'lucide-react';
import { useState } from 'react';
import { User } from '../types';
import { TickerBanner } from './TickerBanner';

interface HeaderProps {
  user: User | null;
  cartCount: number;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  currentPage: string;
}

export function Header({ user, cartCount, onNavigate, onLogout, currentPage }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'Trang chủ', page: 'home' },
    { label: 'Cửa hàng', page: 'shop' },
    { label: 'Giới thiệu', page: 'about' },
    { label: 'Blog', page: 'blog' },
    { label: 'Liên hệ', page: 'contact' },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      {/* Ticker Banner */}
      <TickerBanner />

      <div className="container mx-auto px-3 sm:px-4">
        <div className="flex items-center justify-between h-14 sm:h-16 md:h-20">
          {/* Logo */}
          <button 
            onClick={() => {
              onNavigate('home');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-1.5 sm:gap-2 hover:opacity-80 transition-opacity flex-shrink-0"
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 bg-gradient-to-br from-orange-400 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-base sm:text-xl md:text-2xl">🐾</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-base sm:text-lg md:text-2xl text-gray-900 truncate">GauMeoShop</span>
              <span className="text-xs text-gray-500 hidden sm:block truncate">Chăm sóc thú cưng</span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => onNavigate(item.page)}
                className={`text-gray-700 hover:text-orange-500 transition-colors relative ${
                  currentPage === item.page ? 'text-orange-500' : ''
                }`}
              >
                {item.label}
                {currentPage === item.page && (
                  <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-orange-500"></span>
                )}
              </button>
            ))}
            {user?.role === 'admin' && (
              <button
                onClick={() => onNavigate('admin')}
                className="flex items-center gap-2 text-gray-700 hover:text-orange-500 transition-colors"
              >
                <Shield className="w-5 h-5" />
                <span>Quản trị</span>
              </button>
            )}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-1.5 sm:gap-2 md:gap-4">
            {/* Cart */}
            <button
              onClick={() => {
                onNavigate('cart');
                setMobileMenuOpen(false);
              }}
              className="relative p-1.5 sm:p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0"
            >
              <ShoppingCart className="w-5 h-5 md:w-6 md:h-6 text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs min-w-[20px] h-5 rounded-full flex items-center justify-center px-1">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>

            {/* User menu */}
            {user ? (
              <div className="hidden md:flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm text-gray-900 truncate max-w-[120px]">{user.name}</div>
                  <div className="text-xs text-gray-500">
                    {user.role === 'admin' ? 'Quản trị viên' : 'Khách hàng'}
                  </div>
                </div>
                <button
                  onClick={onLogout}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0"
                  title="Đăng xuất"
                >
                  <LogOut className="w-6 h-6 text-gray-700" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  onNavigate('login');
                  setMobileMenuOpen(false);
                }}
                className="hidden md:flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-full hover:bg-orange-600 transition-colors flex-shrink-0"
              >
                <UserIcon className="w-5 h-5" />
                <span>Đăng nhập</span>
              </button>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-1.5 sm:p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700" />
              ) : (
                <Menu className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-gray-200 bg-white max-h-[calc(100vh-200px)] overflow-y-auto">
          <div className="container mx-auto px-3 sm:px-4 py-4">
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <button
                  key={item.page}
                  onClick={() => {
                    onNavigate(item.page);
                    setMobileMenuOpen(false);
                  }}
                  className={`text-left py-2 px-4 rounded-lg transition-colors ${
                    currentPage === item.page
                      ? 'bg-orange-50 text-orange-500'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              {user?.role === 'admin' && (
                <button
                  onClick={() => {
                    onNavigate('admin');
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 text-left py-2 px-4 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <Shield className="w-5 h-5" />
                  <span>Quản trị</span>
                </button>
              )}
              {user ? (
                <button
                  onClick={() => {
                    onLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 text-left py-2 px-4 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Đăng xuất ({user.name})</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    onNavigate('login');
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 bg-orange-500 text-white py-2 px-4 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  <UserIcon className="w-5 h-5" />
                  <span>Đăng nhập</span>
                </button>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}