import { motion } from 'motion/react';

export function TickerBanner() {
  const announcements = [
    '🎉 Giảm giá 20% toàn bộ thức ăn cho mèo',
    '🚚 Miễn phí vận chuyển đơn hàng từ 1.000.000đ',
    '⭐ Hàng mới về: Đồ chơi cao cấp cho chó',
    '💝 Tích điểm đổi quà hấp dẫn',
    '🎁 Khuyến mãi đặc biệt cuối tuần',
  ];

  const duplicatedAnnouncements = [...announcements, ...announcements, ...announcements];

  return (
    <div className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-500 text-white py-2 overflow-hidden">
      <div className="relative flex">
        <motion.div
          className="flex gap-8 whitespace-nowrap"
          animate={{
            x: [0, -1000],
          }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: 20,
              ease: "linear",
            },
          }}
        >
          {duplicatedAnnouncements.map((announcement, index) => (
            <div key={index} className="flex items-center gap-2">
              <span className="text-sm md:text-base">{announcement}</span>
              <span className="text-yellow-300">•</span>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
