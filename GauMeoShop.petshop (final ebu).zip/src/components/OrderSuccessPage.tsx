import { CheckCircle, Home, Package } from 'lucide-react';

interface OrderSuccessPageProps {
  orderId: string;
  onNavigate: (page: string) => void;
}

export function OrderSuccessPage({ orderId, onNavigate }: OrderSuccessPageProps) {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 py-12 px-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-16 h-16 text-green-600" />
        </div>

        <h1 className="text-4xl text-gray-900 mb-4">Đặt hàng thành công!</h1>
        <p className="text-xl text-gray-600 mb-8">
          Cảm ơn bạn đã mua hàng tại GauMeoShop
        </p>

        <div className="bg-gray-50 rounded-xl p-6 mb-8">
          <div className="text-sm text-gray-600 mb-2">Mã đơn hàng</div>
          <div className="text-3xl text-orange-500 mb-4">{orderId}</div>
          <div className="text-sm text-gray-600">
            Email xác nhận đã được gửi đến địa chỉ email của bạn
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="bg-blue-50 rounded-xl p-6">
            <div className="text-3xl mb-2">📧</div>
            <div className="text-sm text-gray-900 mb-1">Xác nhận email</div>
            <div className="text-xs text-gray-600">Kiểm tra hộp thư</div>
          </div>
          <div className="bg-purple-50 rounded-xl p-6">
            <div className="text-3xl mb-2">📦</div>
            <div className="text-sm text-gray-900 mb-1">Đang xử lý</div>
            <div className="text-xs text-gray-600">1-2 ngày làm việc</div>
          </div>
          <div className="bg-green-50 rounded-xl p-6">
            <div className="text-3xl mb-2">🚚</div>
            <div className="text-sm text-gray-900 mb-1">Giao hàng</div>
            <div className="text-xs text-gray-600">3-5 ngày làm việc</div>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => onNavigate('home')}
            className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors"
          >
            <Home className="w-5 h-5" />
            <span>Về trang chủ</span>
          </button>
          <button
            onClick={() => onNavigate('shop')}
            className="w-full flex items-center justify-center gap-2 border-2 border-orange-500 text-orange-500 py-3 rounded-lg hover:bg-orange-50 transition-colors"
          >
            <Package className="w-5 h-5" />
            <span>Tiếp tục mua sắm</span>
          </button>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200">
          <h3 className="text-lg text-gray-900 mb-4">Điều gì sẽ xảy ra tiếp theo?</h3>
          <div className="text-left space-y-3 max-w-md mx-auto">
            <div className="flex gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-orange-600 text-sm">1</span>
              </div>
              <div>
                <div className="text-sm text-gray-900">Xác nhận đơn hàng</div>
                <div className="text-xs text-gray-600">Bạn sẽ nhận được email xác nhận đơn hàng</div>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-orange-600 text-sm">2</span>
              </div>
              <div>
                <div className="text-sm text-gray-900">Xử lý đơn hàng</div>
                <div className="text-xs text-gray-600">Chúng tôi sẽ chuẩn bị đơn hàng của bạn</div>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-orange-600 text-sm">3</span>
              </div>
              <div>
                <div className="text-sm text-gray-900">Vận chuyển</div>
                <div className="text-xs text-gray-600">Theo dõi gói hàng với mã vận đơn được gửi đến email</div>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-orange-600 text-sm">4</span>
              </div>
              <div>
                <div className="text-sm text-gray-900">Giao hàng</div>
                <div className="text-xs text-gray-600">Sản phẩm cho thú cưng sẽ đến tận nhà bạn</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}