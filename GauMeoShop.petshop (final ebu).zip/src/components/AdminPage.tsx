import { useState } from 'react';
import { Plus, Edit, Trash2, Package } from 'lucide-react';
import { products as initialProducts } from '../data/products';
import { Product } from '../types';
import { formatVND } from '../utils/format';

interface AdminPageProps {
  onNavigate: (page: string) => void;
}

export function AdminPage({ onNavigate }: AdminPageProps) {
  const [products, setProducts] = useState(initialProducts);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);

  const handleDelete = (id: number) => {
    if (confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
      setProducts(products.filter(p => p.id !== id));
    }
  };

  const handleEdit = (product: Product) => {
    setSelectedProduct(product);
    setShowForm(true);
  };

  const handleAddNew = () => {
    setSelectedProduct(null);
    setShowForm(true);
  };

  const handleSave = (product: Product) => {
    if (selectedProduct) {
      // Update existing
      setProducts(products.map(p => p.id === product.id ? product : p));
    } else {
      // Add new
      setProducts([...products, { ...product, id: Date.now() }]);
    }
    setShowForm(false);
  };

  const stats = {
    totalProducts: products.length,
    catProducts: products.filter(p => p.petType === 'cat' || p.petType === 'both').length,
    dogProducts: products.filter(p => p.petType === 'dog' || p.petType === 'both').length,
    lowStock: products.filter(p => p.stock < 30).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-4xl text-gray-900 mb-2">Bảng điều khiển quản trị</h1>
          <p className="text-gray-600">Quản lý sản phẩm và tồn kho</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-gray-600 mb-1">Tổng sản phẩm</div>
                <div className="text-3xl text-gray-900">{stats.totalProducts}</div>
              </div>
              <Package className="w-12 h-12 text-orange-500" />
            </div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-gray-600 mb-1">Sản phẩm cho mèo</div>
                <div className="text-3xl text-gray-900">{stats.catProducts}</div>
              </div>
              <span className="text-4xl">🐱</span>
            </div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-gray-600 mb-1">Sản phẩm cho chó</div>
                <div className="text-3xl text-gray-900">{stats.dogProducts}</div>
              </div>
              <span className="text-4xl">🐶</span>
            </div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-gray-600 mb-1">Sắp hết hàng</div>
                <div className="text-3xl text-gray-900">{stats.lowStock}</div>
              </div>
              <span className="text-4xl">⚠️</span>
            </div>
          </div>
        </div>

        {/* Products Table */}
        <div className="bg-white rounded-2xl shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-2xl text-gray-900">Sản phẩm</h2>
            <button
              onClick={handleAddNew}
              className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Thêm sản phẩm</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-gray-600">Sản phẩm</th>
                  <th className="px-6 py-3 text-left text-gray-600">Danh mục</th>
                  <th className="px-6 py-3 text-left text-gray-600">Loại thú cưng</th>
                  <th className="px-6 py-3 text-left text-gray-600">Giá</th>
                  <th className="px-6 py-3 text-left text-gray-600">Tồn kho</th>
                  <th className="px-6 py-3 text-left text-gray-600">Hành động</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {products.map(product => (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div>
                          <div className="text-gray-900">{product.name}</div>
                          <div className="text-sm text-gray-500">{product.description.slice(0, 40)}...</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">
                        {product.category}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-2xl">
                        {product.petType === 'both' ? '🐱🐶' : product.petType === 'cat' ? '🐱' : '🐶'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-900">{formatVND(product.price)}</td>
                    <td className="px-6 py-4">
                      <span className={`${product.stock < 30 ? 'text-red-600' : 'text-gray-900'}`}>
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleEdit(product)}
                          className="p-2 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit className="w-5 h-5 text-blue-600" />
                        </button>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-5 h-5 text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Product Form Modal */}
      {showForm && (
        <ProductForm
          product={selectedProduct}
          onSave={handleSave}
          onCancel={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

interface ProductFormProps {
  product: Product | null;
  onSave: (product: Product) => void;
  onCancel: () => void;
}

function ProductForm({ product, onSave, onCancel }: ProductFormProps) {
  const [formData, setFormData] = useState<Product>(
    product || {
      id: 0,
      name: '',
      category: 'food',
      petType: 'both',
      price: 0,
      image: '',
      description: '',
      stock: 0
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-2xl text-gray-900">
            {product ? 'Chỉnh sửa sản phẩm' : 'Thêm sản phẩm mới'}
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-gray-700 mb-2">Tên sản phẩm</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 mb-2">Danh mục</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
              >
                <option value="food">Thức ăn</option>
                <option value="drink">Đồ uống</option>
                <option value="medicine">Thuốc men</option>
                <option value="supplies">Đồ dùng</option>
                <option value="toys">Đồ chơi</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Loại thú cưng</label>
              <select
                value={formData.petType}
                onChange={(e) => setFormData({ ...formData, petType: e.target.value as any })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
              >
                <option value="cat">Mèo</option>
                <option value="dog">Chó</option>
                <option value="both">Cả hai</option>
              </select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 mb-2">Giá (VND)</label>
              <input
                type="number"
                step="1000"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Tồn kho</label>
              <input
                type="number"
                value={formData.stock}
                onChange={(e) => setFormData({ ...formData, stock: parseInt(e.target.value) })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-700 mb-2">URL hình ảnh</label>
            <input
              type="url"
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700 mb-2">Mô tả</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
              rows={3}
              required
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors"
            >
              {product ? 'Cập nhật sản phẩm' : 'Thêm sản phẩm'}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Hủy
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}