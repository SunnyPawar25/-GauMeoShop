import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CartItem } from '../types';
import { formatVND } from '../utils/format';

interface CartPageProps {
  cart: CartItem[];
  onNavigate: (page: string) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  removeItem: (productId: number) => void;
}

const categoryNames: Record<string, string> = {
  food: 'Thức ăn',
  drink: 'Đồ uống',
  medicine: 'Thuốc',
  supplies: 'Phụ kiện',
  toys: 'Đồ chơi'
};

export function CartPage({ cart, onNavigate, updateQuantity, removeItem }: CartPageProps) {
  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const shipping = subtotal >= 1000000 ? 0 : 50000; // Free shipping for orders over 1,000,000 VND
  const tax = 0; // No tax for Vietnam
  const total = subtotal + shipping + tax;

  if (cart.length === 0) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="text-center">
          <div className="text-6xl mb-4">🛒</div>
          <h2 className="text-3xl text-gray-900 mb-2">Giỏ hàng trống</h2>
          <p className="text-gray-600 mb-6">Thêm sản phẩm vào giỏ hàng để tiếp tục mua sắm</p>
          <button
            onClick={() => onNavigate('shop')}
            className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600 transition-colors"
          >
            Bắt đầu mua sắm
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-4xl text-gray-900 mb-2">Giỏ hàng</h1>
          <p className="text-gray-600">{cart.length} sản phẩm trong giỏ hàng của bạn</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div key={item.product.id} className="bg-white rounded-2xl shadow-md p-6">
                <div className="flex gap-4">
                  <div className="w-24 h-24 flex-shrink-0">
                    <ImageWithFallback
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-xl text-gray-900 mb-1">{item.product.name}</h3>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-orange-500 uppercase">{categoryNames[item.product.category]}</span>
                          <span className="text-gray-300">•</span>
                          <span className="text-sm text-gray-500">
                            {item.product.petType === 'both' ? '🐱🐶' : item.product.petType === 'cat' ? '🐱 Cho mèo' : '🐶 Cho chó'}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-5 h-5 text-red-600" />
                      </button>
                    </div>

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-lg text-gray-900 w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:bg-gray-100 disabled:cursor-not-allowed"
                          disabled={item.quantity >= item.product.stock}
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                        {item.quantity >= item.product.stock && (
                          <span className="text-sm text-red-600">Hết hàng</span>
                        )}
                      </div>
                      <div className="text-2xl text-gray-900">
                        {formatVND(item.product.price * item.quantity)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
              <h2 className="text-2xl text-gray-900 mb-6">Tóm tắt đơn hàng</h2>

              <div className="space-y-3 mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Tạm tính</span>
                  <span className="text-gray-900">{formatVND(subtotal)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Vận chuyển</span>
                  <span className="text-gray-900">
                    {shipping === 0 ? (
                      <span className="text-green-600">Miễn phí</span>
                    ) : (
                      formatVND(shipping)
                    )}
                  </span>
                </div>
                <div className="border-t border-gray-200 pt-3 mt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xl text-gray-900">Tổng cộng</span>
                    <span className="text-2xl text-gray-900">{formatVND(total)}</span>
                  </div>
                </div>
              </div>

              {subtotal < 1000000 && (
                <div className="bg-blue-50 text-blue-700 px-4 py-3 rounded-lg mb-6 text-sm">
                  Mua thêm {formatVND(1000000 - subtotal)} để được miễn phí vận chuyển!
                </div>
              )}

              <button
                onClick={() => onNavigate('checkout')}
                className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors mb-3"
              >
                <span>Thanh toán</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => onNavigate('shop')}
                className="w-full text-orange-500 py-3 rounded-lg hover:bg-orange-50 transition-colors"
              >
                Tiếp tục mua sắm
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}