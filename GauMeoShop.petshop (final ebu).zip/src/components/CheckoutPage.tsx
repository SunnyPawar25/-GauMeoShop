import { useState } from 'react';
import { CreditCard, Lock, Truck, DollarSign, Clock, Banknote, Building2 } from 'lucide-react';
import { CartItem, User } from '../types';
import { formatVND } from '../utils/format';

interface CheckoutPageProps {
  cart: CartItem[];
  user: User | null;
  onNavigate: (page: string) => void;
  onCheckout: (orderId: string) => void;
}

export function CheckoutPage({ cart, user, onNavigate, onCheckout }: CheckoutPageProps) {
  const [shippingInfo, setShippingInfo] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    city: '',
    zipCode: ''
  });

  const [shippingMethod, setShippingMethod] = useState('standard');
  const [paymentMethod, setPaymentMethod] = useState('credit-card');

  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: '',
    // For bank transfer
    bankName: '',
    accountNumber: '',
    accountName: ''
  });

  const shippingOptions = [
    {
      id: 'express',
      name: 'Giao hàng hỏa tốc',
      description: '1-2 ngày làm việc',
      price: 50000,
      icon: Clock
    },
    {
      id: 'standard',
      name: 'Giao hàng tiêu chuẩn',
      description: '3-5 ngày làm việc',
      price: 30000,
      icon: Truck
    },
    {
      id: 'economy',
      name: 'Giao hàng tiết kiệm',
      description: '7-10 ngày làm việc',
      price: 15000,
      icon: DollarSign
    }
  ];

  const paymentOptions = [
    {
      id: 'credit-card',
      name: 'Thẻ tín dụng',
      description: 'Thanh toán bằng Visa, Mastercard',
      icon: CreditCard
    },
    {
      id: 'bank-transfer',
      name: 'Chuyển khoản ngân hàng',
      description: 'Chuyển khoản trực tiếp',
      icon: Building2
    },
    {
      id: 'cod',
      name: 'Thanh toán khi nhận hàng',
      description: 'Trả tiền mặt khi nhận',
      icon: Banknote
    }
  ];

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const selectedShipping = shippingOptions.find(s => s.id === shippingMethod);
  const shipping = subtotal > 500000 && shippingMethod === 'standard' ? 0 : (selectedShipping?.price || 0);
  const tax = 0; // No tax in Vietnam for this purpose
  const total = subtotal + shipping + tax;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate payment processing
    const orderId = 'GMS' + Date.now().toString().slice(-8);
    
    // In a real app, you would process payment here
    setTimeout(() => {
      onCheckout(orderId);
    }, 1000);
  };

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Lock className="w-24 h-24 text-gray-300 mx-auto mb-6" />
          <h2 className="text-3xl text-gray-900 mb-4">Vui lòng đăng nhập để thanh toán</h2>
          <p className="text-gray-600 mb-8">Bạn cần đăng nhập để hoàn tất đơn hàng</p>
          <button
            onClick={() => onNavigate('login')}
            className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600 transition-colors"
          >
            Đến trang đăng nhập
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-4xl text-gray-900 mb-2">Thanh toán</h1>
          <p className="text-gray-600">Hoàn tất đơn hàng của bạn</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Forms */}
            <div className="lg:col-span-2 space-y-6">
              {/* Shipping Information */}
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="text-2xl text-gray-900 mb-6">Thông tin giao hàng</h2>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 mb-2">Họ và tên</label>
                    <input
                      type="text"
                      value={shippingInfo.name}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, name: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Số điện thoại</label>
                    <input
                      type="tel"
                      value={shippingInfo.phone}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Tỉnh/Thành phố</label>
                    <input
                      type="text"
                      value={shippingInfo.city}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-gray-700 mb-2">Địa chỉ</label>
                    <input
                      type="text"
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-2">Mã bưu điện</label>
                    <input
                      type="text"
                      value={shippingInfo.zipCode}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Shipping Method */}
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="text-2xl text-gray-900 mb-6">Phương thức vận chuyển</h2>
                
                <div className="space-y-3">
                  {shippingOptions.map((option) => {
                    const Icon = option.icon;
                    return (
                      <label
                        key={option.id}
                        className={`flex items-center justify-between p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          shippingMethod === option.id
                            ? 'border-orange-500 bg-orange-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <input
                            type="radio"
                            name="shipping"
                            value={option.id}
                            checked={shippingMethod === option.id}
                            onChange={(e) => setShippingMethod(e.target.value)}
                            className="w-5 h-5 text-orange-500"
                          />
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                              <Icon className="w-5 h-5 text-orange-500" />
                            </div>
                            <div>
                              <div className="text-gray-900">{option.name}</div>
                              <div className="text-sm text-gray-500">{option.description}</div>
                            </div>
                          </div>
                        </div>
                        <div className="text-gray-900">
                          {subtotal > 500000 && option.id === 'standard' ? (
                            <span className="text-green-600">MIỄN PHÍ</span>
                          ) : (
                            formatVND(option.price)
                          )}
                        </div>
                      </label>
                    );
                  })}
                </div>

                {subtotal > 500000 && (
                  <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-lg text-sm">
                    🎉 Đơn hàng của bạn được miễn phí vận chuyển tiêu chuẩn!
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div className="bg-white rounded-2xl shadow-md p-6">
                <h2 className="text-2xl text-gray-900 mb-6">Phương thức thanh toán</h2>
                
                <div className="space-y-3 mb-6">
                  {paymentOptions.map((option) => {
                    const Icon = option.icon;
                    return (
                      <label
                        key={option.id}
                        className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          paymentMethod === option.id
                            ? 'border-orange-500 bg-orange-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment"
                          value={option.id}
                          checked={paymentMethod === option.id}
                          onChange={(e) => setPaymentMethod(e.target.value)}
                          className="w-5 h-5 text-orange-500"
                        />
                        <div className="flex items-center gap-3 ml-3">
                          <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                            <Icon className="w-5 h-5 text-orange-500" />
                          </div>
                          <div>
                            <div className="text-gray-900">{option.name}</div>
                            <div className="text-sm text-gray-500">{option.description}</div>
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>

                {/* Credit Card Form */}
                {paymentMethod === 'credit-card' && (
                  <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                    <div className="bg-yellow-50 text-yellow-800 px-4 py-3 rounded-lg text-sm">
                      <strong>Chế độ Demo:</strong> Sử dụng số thẻ demo (vd: 4242 4242 4242 4242)
                    </div>

                    <div>
                      <label className="block text-gray-700 mb-2">Số thẻ</label>
                      <input
                        type="text"
                        value={paymentInfo.cardNumber}
                        onChange={(e) => setPaymentInfo({ ...paymentInfo, cardNumber: e.target.value })}
                        placeholder="1234 5678 9012 3456"
                        maxLength={19}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-gray-700 mb-2">Tên chủ thẻ</label>
                      <input
                        type="text"
                        value={paymentInfo.cardName}
                        onChange={(e) => setPaymentInfo({ ...paymentInfo, cardName: e.target.value })}
                        placeholder="NGUYEN VAN A"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 mb-2">Ngày hết hạn</label>
                        <input
                          type="text"
                          value={paymentInfo.expiryDate}
                          onChange={(e) => setPaymentInfo({ ...paymentInfo, expiryDate: e.target.value })}
                          placeholder="MM/YY"
                          maxLength={5}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 mb-2">CVV</label>
                        <input
                          type="text"
                          value={paymentInfo.cvv}
                          onChange={(e) => setPaymentInfo({ ...paymentInfo, cvv: e.target.value })}
                          placeholder="123"
                          maxLength={4}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none"
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Bank Transfer Info */}
                {paymentMethod === 'bank-transfer' && (
                  <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                    <div className="bg-blue-50 text-blue-800 px-4 py-3 rounded-lg text-sm space-y-2">
                      <strong>Thông tin chuyển khoản:</strong>
                      <div>Ngân hàng: GauMeo Bank</div>
                      <div>Số tài khoản: 123-456-789</div>
                      <div>Tên tài khoản: CONG TY GAUMEOSHOP</div>
                      <div className="mt-2">Vui lòng ghi mã đơn hàng vào nội dung chuyển khoản.</div>
                    </div>
                  </div>
                )}

                {/* COD Info */}
                {paymentMethod === 'cod' && (
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="bg-green-50 text-green-800 px-4 py-3 rounded-lg text-sm">
                      <strong>Thanh toán khi nhận hàng:</strong> Vui lòng chuẩn bị {formatVND(total)} khi nhận hàng. Nhân viên giao hàng sẽ thu tiền khi giao hàng.
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-md p-6 sticky top-24">
                <h2 className="text-2xl text-gray-900 mb-6">Tóm tắt đơn hàng</h2>

                {/* Items */}
                <div className="space-y-3 mb-6 max-h-60 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={item.product.id} className="flex gap-3">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="text-sm text-gray-900">{item.product.name}</div>
                        <div className="text-sm text-gray-500">SL: {item.quantity}</div>
                        <div className="text-sm text-gray-900">
                          {formatVND(item.product.price * item.quantity)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="space-y-3 mb-6 border-t border-gray-200 pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Tạm tính</span>
                    <span className="text-gray-900">{formatVND(subtotal)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">
                      Vận chuyển ({shippingOptions.find(s => s.id === shippingMethod)?.name})
                    </span>
                    <span className="text-gray-900">
                      {shipping === 0 ? (
                        <span className="text-green-600">MIỄN PHÍ</span>
                      ) : (
                        formatVND(shipping)
                      )}
                    </span>
                  </div>
                  <div className="border-t border-gray-200 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xl text-gray-900">Tổng cộng</span>
                      <span className="text-2xl text-gray-900">{formatVND(total)}</span>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors mb-3"
                >
                  <Lock className="w-5 h-5" />
                  <span>Đặt hàng</span>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('cart')}
                  className="w-full text-orange-500 py-3 rounded-lg hover:bg-orange-50 transition-colors"
                >
                  Quay lại giỏ hàng
                </button>

                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                  <Lock className="w-4 h-4" />
                  <span>Thanh toán bảo mật</span>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}