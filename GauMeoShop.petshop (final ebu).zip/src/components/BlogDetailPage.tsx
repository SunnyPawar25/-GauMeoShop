import { Calendar, User, Tag, Share2, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { blogPosts } from './BlogPage';

interface BlogDetailPageProps {
  blogId: number;
  onNavigate: (page: string) => void;
  viewBlog: (blogId: number) => void;
}

export function BlogDetailPage({ blogId, onNavigate, viewBlog }: BlogDetailPageProps) {
  const post = blogPosts.find(p => p.id === blogId) || blogPosts[0];
  const relatedPosts = blogPosts.filter(p => p.id !== blogId && p.category === post.category).slice(0, 3);

  return (
    <div className="min-h-screen bg-white py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Back Button */}
        <button
          onClick={() => onNavigate('blog')}
          className="flex items-center gap-2 text-gray-600 hover:text-orange-500 transition-colors mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Quay lại Blog</span>
        </button>

        {/* Article Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <span className="bg-orange-100 text-orange-600 px-4 py-2 rounded-full">
              {post.category}
            </span>
            <span className="text-gray-500">{post.readTime}</span>
          </div>
          <h1 className="text-5xl text-gray-900 mb-6">{post.title}</h1>
          <div className="flex items-center gap-6 text-gray-600">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5" />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              <span>{post.date}</span>
            </div>
            <button className="flex items-center gap-2 hover:text-orange-500 transition-colors">
              <Share2 className="w-5 h-5" />
              <span>Chia sẻ</span>
            </button>
          </div>
        </div>

        {/* Featured Image */}
        <div className="rounded-2xl overflow-hidden shadow-2xl mb-12">
          <ImageWithFallback
            src={post.image}
            alt={post.title}
            className="w-full h-[500px] object-cover"
          />
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none">
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            {post.excerpt}
          </p>

          <h2 className="text-3xl text-gray-900 mb-4">Giới thiệu</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Chăm sóc thú cưng không chỉ đơn giản là cho chúng ăn và chỗ ở. Để thú cưng phát triển khỏe mạnh và hạnh phúc, 
            chúng ta cần hiểu rõ nhu cầu của chúng và cung cấp những gì tốt nhất. Bài viết này sẽ chia sẻ những kiến thức 
            quan trọng giúp bạn chăm sóc người bạn bốn chân một cách tốt nhất.
          </p>

          <h2 className="text-3xl text-gray-900 mb-4">Những điều cần biết</h2>
          <p className="text-gray-700 mb-4 leading-relaxed">
            Việc chăm sóc thú cưng đòi hỏi sự kiên nhẫn và tận tâm. Dưới đây là những điểm quan trọng bạn cần lưu ý:
          </p>

          <ul className="list-disc pl-6 mb-6 space-y-2 text-gray-700">
            <li>Cung cấp dinh dưỡng cân bằng và phù hợp với lứa tuổi</li>
            <li>Đảm bảo vệ sinh sạch sẽ và môi trường sống thoải mái</li>
            <li>Thường xuyên kiểm tra sức khỏe và tiêm phòng đầy đủ</li>
            <li>Dành thời gian chơi đùa và tương tác với thú cưng</li>
            <li>Huấn luyện và giáo dục đúng cách từ khi còn nhỏ</li>
          </ul>

          <h2 className="text-3xl text-gray-900 mb-4">Lời khuyên từ chuyên gia</h2>
          <blockquote className="border-l-4 border-orange-500 pl-6 italic text-gray-700 mb-6 bg-orange-50 py-4 rounded-r-lg">
            "Việc hiểu rõ nhu cầu và hành vi của thú cưng là chìa khóa để xây dựng mối quan hệ bền vững và tin tưởng. 
            Hãy luôn quan sát và lắng nghe thú cưng của bạn." - Bác sĩ thú y Nguyễn Văn A
          </blockquote>

          <h2 className="text-3xl text-gray-900 mb-4">Kết luận</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Chăm sóc thú cưng là một trách nhiệm lâu dài nhưng cũng mang lại niềm vui và hạnh phúc to lớn. 
            Hy vọng những thông tin trong bài viết này sẽ giúp bạn có thêm kiến thức để chăm sóc người bạn bốn chân 
            của mình một cách tốt nhất. Nếu có bất kỳ thắc mắc nào, đừng ngần ngại liên hệ với chúng tôi hoặc tham khảo 
            ý kiến của bác sĩ thú y.
          </p>
        </div>

        {/* Tags */}
        <div className="flex items-center gap-3 my-12 pt-8 border-t border-gray-200">
          <Tag className="w-5 h-5 text-gray-500" />
          <div className="flex gap-2 flex-wrap">
            <span className="bg-gray-100 text-gray-700 px-4 py-2 rounded-full text-sm">{post.category}</span>
            <span className="bg-gray-100 text-gray-700 px-4 py-2 rounded-full text-sm">Thú cưng</span>
            <span className="bg-gray-100 text-gray-700 px-4 py-2 rounded-full text-sm">Chăm sóc</span>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mt-16 pt-8 border-t border-gray-200">
            <h3 className="text-3xl text-gray-900 mb-8">Bài viết liên quan</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {relatedPosts.map(relatedPost => (
                <div
                  key={relatedPost.id}
                  onClick={() => viewBlog(relatedPost.id)}
                  className="bg-white border border-gray-200 rounded-xl overflow-hidden cursor-pointer hover:shadow-lg transition-shadow"
                >
                  <ImageWithFallback
                    src={relatedPost.image}
                    alt={relatedPost.title}
                    className="w-full h-40 object-cover"
                  />
                  <div className="p-4">
                    <h4 className="text-lg text-gray-900 mb-2 line-clamp-2">{relatedPost.title}</h4>
                    <p className="text-sm text-gray-600 line-clamp-2">{relatedPost.excerpt}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
