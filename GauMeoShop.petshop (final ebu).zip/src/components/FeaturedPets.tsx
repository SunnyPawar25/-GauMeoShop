import { Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const pets = [
  {
    id: 1,
    name: 'Charlie',
    type: 'Golden Retriever',
    age: '8 weeks',
    price: 1200,
    image: 'https://images.unsplash.com/photo-1534361960057-19889db9621e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZ3xlbnwxfHx8fDE3NjU1ODk4NzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: 2,
    name: 'Luna',
    type: 'Persian Cat',
    age: '10 weeks',
    price: 800,
    image: 'https://images.unsplash.com/photo-1529778873920-4da4926a72c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXRlJTIwY2F0fGVufDF8fHx8MTc2NTYzMzkxNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: 3,
    name: 'Tweety',
    type: 'Parakeet',
    age: '6 months',
    price: 150,
    image: 'https://images.unsplash.com/photo-1522858547137-f1dcec554f55?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBiaXJkfGVufDF8fHx8MTc2NTY0MjkwN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export function FeaturedPets() {
  return (
    <section id="pets" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-5xl text-gray-900 mb-4">Meet Your New Best Friend</h2>
          <p className="text-xl text-gray-600">Healthy, happy pets looking for loving homes</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {pets.map((pet) => (
            <div key={pet.id} className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300">
              <div className="relative overflow-hidden">
                <ImageWithFallback 
                  src={pet.image}
                  alt={pet.name}
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <button className="absolute top-4 right-4 bg-white p-2 rounded-full hover:bg-purple-50 transition-colors">
                  <Heart className="w-5 h-5 text-purple-600" />
                </button>
              </div>
              <div className="p-6">
                <h3 className="text-2xl text-gray-900 mb-2">{pet.name}</h3>
                <p className="text-gray-600 mb-4">{pet.type} • {pet.age}</p>
                <div className="flex items-center justify-between">
                  <span className="text-3xl text-purple-600">${pet.price}</span>
                  <button className="bg-purple-600 text-white px-6 py-2 rounded-full hover:bg-purple-700 transition-colors">
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
