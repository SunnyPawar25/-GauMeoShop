import { useState } from 'react';
import { Search, Filter, ShoppingBag } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Product } from '../types';
import { products } from '../data/products';
import { formatVND } from '../utils/format';

interface ShopPageProps {
  onNavigate: (page: string) => void;
  addToCart: (product: Product) => void;
  viewProduct: (product: Product) => void;
}

export function ShopPage({ onNavigate, addToCart, viewProduct }: ShopPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPetType, setSelectedPetType] = useState<string>('all');

  const categoryNames: Record<string, string> = {
    food: 'Thức ăn',
    drink: 'Đồ uống',
    medicine: 'Thuốc',
    supplies: 'Phụ kiện',
    toys: 'Đồ chơi'
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesPetType = selectedPetType === 'all' || 
                          product.petType === selectedPetType || 
                          product.petType === 'both';
    
    return matchesSearch && matchesCategory && matchesPetType;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-6 sm:py-8">
      <div className="container mx-auto px-3 sm:px-4">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl text-gray-900 mb-1 sm:mb-2">Cửa hàng</h1>
          <p className="text-sm sm:text-base text-gray-600">Khám phá bộ sưu tập sản phẩm thú cưng của chúng tôi</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-md p-4 sm:p-6 mb-6 sm:mb-8">
          <div className="grid md:grid-cols-4 gap-3 sm:gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Tìm kiếm sản phẩm..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 sm:pl-10 pr-3 sm:pr-4 py-2.5 sm:py-3 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none text-sm sm:text-base"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 sm:px-4 py-2.5 sm:py-3 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none text-sm sm:text-base"
              >
                <option value="all">Tất cả danh mục</option>
                <option value="food">Thức ăn</option>
                <option value="drink">Đồ uống</option>
                <option value="medicine">Thuốc</option>
                <option value="supplies">Phụ kiện</option>
                <option value="toys">Đồ chơi</option>
              </select>
            </div>

            {/* Pet Type Filter */}
            <div>
              <select
                value={selectedPetType}
                onChange={(e) => setSelectedPetType(e.target.value)}
                className="w-full px-3 sm:px-4 py-2.5 sm:py-3 border border-gray-300 rounded-lg focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none text-sm sm:text-base"
              >
                <option value="all">Tất cả thú cưng</option>
                <option value="cat">Mèo 🐱</option>
                <option value="dog">Chó 🐶</option>
              </select>
            </div>
          </div>

          {/* Filter Tags */}
          <div className="mt-3 sm:mt-4 flex items-center gap-2 flex-wrap">
            <Filter className="w-4 h-4 text-gray-500" />
            <span className="text-xs sm:text-sm text-gray-600">Bộ lọc:</span>
            {selectedCategory !== 'all' && (
              <span className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm">
                {categoryNames[selectedCategory]}
              </span>
            )}
            {selectedPetType !== 'all' && (
              <span className="bg-pink-100 text-pink-800 px-3 py-1 rounded-full text-sm">
                {selectedPetType === 'cat' ? 'Mèo 🐱' : 'Chó 🐶'}
              </span>
            )}
            {searchTerm && (
              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                Tìm kiếm: "{searchTerm}"
              </span>
            )}
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-4 sm:mb-6">
          <p className="text-sm sm:text-base text-gray-600">
            Hiển thị <span className="text-gray-900">{filteredProducts.length}</span> sản phẩm
          </p>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
            {filteredProducts.map(product => (
              <div
                key={product.id}
                onClick={() => viewProduct(product)}
                className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-all cursor-pointer group"
              >
                <div className="relative overflow-hidden">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-40 md:h-56 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <span className="absolute top-2 md:top-3 right-2 md:right-3 bg-orange-500 text-white px-2 md:px-3 py-1 rounded-full text-xs md:text-sm">
                    {product.petType === 'both' ? '🐱🐶' : product.petType === 'cat' ? '🐱' : '🐶'}
                  </span>
                  {product.stock < 30 && product.stock > 0 && (
                    <span className="absolute top-2 md:top-3 left-2 md:left-3 bg-red-500 text-white px-2 md:px-3 py-1 rounded-full text-xs md:text-sm">
                      Sắp hết
                    </span>
                  )}
                  {product.stock === 0 && (
                    <span className="absolute top-2 md:top-3 left-2 md:left-3 bg-gray-900 text-white px-2 md:px-3 py-1 rounded-full text-xs md:text-sm">
                      Hết hàng
                    </span>
                  )}
                </div>
                <div className="p-3 md:p-5">
                  <div className="text-xs md:text-sm text-orange-500 mb-1 md:mb-2 uppercase">{categoryNames[product.category]}</div>
                  <h3 className="text-sm md:text-lg text-gray-900 mb-1 md:mb-2 line-clamp-2">{product.name}</h3>
                  <p className="text-gray-600 text-xs md:text-sm mb-2 md:mb-4 line-clamp-2 hidden md:block">{product.description}</p>
                  <div className="flex items-center justify-between mb-2 md:mb-3">
                    <span className="text-base md:text-2xl text-gray-900">{formatVND(product.price)}</span>
                    <span className="text-xs md:text-sm text-gray-500">Kho: {product.stock}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      addToCart(product);
                    }}
                    className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white py-2 rounded-lg hover:bg-orange-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-sm md:text-base"
                    disabled={product.stock === 0}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span className="hidden md:inline">{product.stock === 0 ? 'Hết hàng' : 'Thêm vào giỏ'}</span>
                    <span className="md:hidden">{product.stock === 0 ? 'Hết' : 'Mua'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl text-gray-900 mb-2">Không tìm thấy sản phẩm</h3>
            <p className="text-gray-600 mb-6">Thử điều chỉnh bộ lọc hoặc từ khóa tìm kiếm</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedPetType('all');
              }}
              className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors"
            >
              Xóa bộ lọc
            </button>
          </div>
        )}
      </div>
    </div>
  );
}