
  # GauMeoShop.petshop (final ebu)

  This is a code bundle for GauMeoShop.petshop (final ebu). The original project is available at https://www.figma.com/design/m03Vl4MDqFsjvrxzugsiCu/GauMeoShop.petshop--final-ebu-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  